import ReactDOM from 'react-dom';
import  GridItems from '../../src/components/gridItems'


describe('GridItems component test suite', () => {


    beforeEach(() => {
        
    })

    afterEach(() => {
       
    })

    test('initial test', () => {
        expect(true).toBeTruthy();
    })
}) 