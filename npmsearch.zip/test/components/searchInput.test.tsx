import ReactDOM from 'react-dom';
import  SearchInput from '../../src/components/searchInput'


describe('SearchInput component test suite', () => {


    beforeEach(() => {
        
    })

    afterEach(() => {
       
    })

    test('initial test', () => {
        expect(true).toBeTruthy();
    })
}) 