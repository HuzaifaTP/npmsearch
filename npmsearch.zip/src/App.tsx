//  Page reserved for application wide cross-cutting features:
//    1. Session
//    2. Routing
//    3. Authentication

import Main from "./Main";

function App() {
  return (
      <Main />
  );
}

export default App;
